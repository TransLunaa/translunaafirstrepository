Hi, i just wanted to say this python file does not install python and the library requests so you will need to install those manually
If youre having trouble downloading python, heres the official downloader of python 3.11.4: https://www.python.org/downloads/release/python-3114/
If youre having trouble downloading the requests library then after downloading python run this in your command prompt: pip install requests
Once youve donwloaded both you just need to right click the python file and select open with python 3.11
Also the dates in this program follow the YYYY-MM-DD format

And one last thing i am not affiliated with wynncraft in any way, nor do i claim to be, this is only a project that uses the wynncraft public API

Credits: Lucy for beta-testing and suggesting improvements
	 My dad for helping with making code i couldnt make alone